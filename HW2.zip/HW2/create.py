from app import db, app

# Create an application context
with app.app_context():
    # Call db.create_all() within the application context
    db.create_all()

