from flask import Flask, request, redirect
from flask.templating import render_template
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate, migrate

app = Flask(__name__)
app.debug = True

# adding configuration for using a sqlite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'

# Creating an SQLAlchemy instance
db = SQLAlchemy(app)

migrate = Migrate(app,db)

# Models
class Profile(db.Model):
	name = db.Column(db.String(40), unique=False, nullable=False)
	id = db.Column(db.Integer, primary_key=True)
	points = db.Column(db.Integer, nullable=False)

	# repr method represents how one object of this datatable
	# will look like
	def __repr__(self):
		return f"Name : {self.name}, ID : {self.id}, Points: {self.points}"

@app.route('/')
def index():
	profiles = Profile.query.all()
	return render_template('index.html',profiles=profiles)

@app.route('/add_data')
def add_data():
	return render_template('add_data.html')

@app.route('/add', methods=["POST"])
def profile():
     
    # In this function we will input data from the
    # form page and store it in our database.
    # Remember that inside the get the name should
    # exactly be the same as that in the html
    # input fields
    name = request.form.get("name")
    id = request.form.get("id")
    points = request.form.get("points")
 
    # create an object of the Profile class of models
    # and store data as a row in our datatable
    if name != '' and id is not None and points is not None:
        p = Profile(name=name, id=id, points=points)
        db.session.add(p)
        db.session.commit()
        return redirect('/')
    else:
        return redirect('/')

@app.route('/delete/<int:id>')
def erase(id):
     
    # deletes the data on the basis of unique id and
    # directs to home page
    data = Profile.query.get(id)
    db.session.delete(data)
    db.session.commit()
    return redirect('/')

@app.route('/search')
def search():
	return render_template('search.html',data = '')

@app.route('/search/<int:id>')
def found(id):
	data = Profile.query.get(id)
	return render_template('search.html', data=data)


if __name__ == '__main__':
	app.run(port=5001)

